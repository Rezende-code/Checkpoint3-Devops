﻿namespace PadariaDoceAroma.Models
{
    public enum TipoCategoria
    {
        Salgado, Doce, Bebida
    }
}
